
// Countdown to 14 Feb
const targetDate = new Date("Feb 14, 2026 00:00:00").getTime();
setInterval(() => {
  const now = new Date().getTime();
  const diff = targetDate - now;
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  document.getElementById("countdown").innerHTML = `Only ${days} days left 💕`;
}, 1000);

// Background Music
const music = document.getElementById("bgMusic");
function toggleMusic() {
  if (music.paused) { music.play(); } else { music.pause(); }
}
